const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const nodemailer = require("nodemailer"); // ✅ ADD THIS

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/bookingDB")
    .then(() => console.log("MongoDB Connected"))
    .catch((err) => console.log(err));

// Import Booking Model
const Booking = require("./models/Booking");

// ✅ EMAIL SETUP
const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false,
    auth: {
        user: "your_email@gmail.com",
        pass: "lnpuemzwovqswspu",
    },
});

// Test Route
app.get("/", (req, res) => {
    res.send("Server is running...");
});

// API to save booking
app.post("/api/book", async (req, res) => {
    try {
        const newBooking = new Booking(req.body);

        // Save to DB
        await newBooking.save();

        // ✅ EMAIL CODE HERE (INSIDE async)
        const mailOptions = {
            from: "your_email@gmail.com",
            to: req.body.email,
            subject: "Booking Confirmation",
            text: `Hello ${req.body.name}, your booking is confirmed!`,
        };

        //await transporter.sendMail(mailOptions);

        res.status(200).json({
            message: "Booking saved successfully",
        });

    } catch (error) {
        console.error("ERROR:", error);
        res.status(500).json({
            error: "Error saving booking",
        });
    }
});

// Start Server
const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});